import discord
from discord.ext import commands
import os

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")


@bot.command()
async def ping(ctx):
    await ctx.send("Pong!")


@bot.command()
async def hello(ctx):
    await ctx.send(f"Hello {ctx.author.mention}!")


@bot.command()
async def info(ctx):
    await ctx.send("I am TazBot, a Discord bot created in Python!")


@bot.command()
async def say(ctx, *, message):
    await ctx.send(message)


@bot.command()
async def help_commands(ctx):
    embed = discord.Embed(title="🤖 TazBot Commands", color=0x00FF00)

    embed.add_field(
        name="🎮 Fun & Games",
        value="""
`!roll <number>` - Roll a dice (1 to specified number)
`!flip` - Flip a coin
`!joke` - Get a random joke
    """,
        inline=False,
    )

    embed.add_field(
        name="🔧 Utility",
        value="""
`!calculate <expression>` - Simple calculator
`!userinfo` - Get information about yourself
`!serverinfo` - Get information about this server
    """,
        inline=False,
    )

    embed.add_field(
        name="💬 General",
        value="""
`!ping` - Get a pong response
`!hello` - Get a personalized greeting
`!info` - Learn about this bot
`!say <message>` - Make the bot say something
`!help_commands` - Show this help message
    """,
        inline=False,
    )

    embed.set_footer(text="TazBot - Your Discord Companion")
    await ctx.send(embed=embed)


@bot.command()
async def roll(ctx, sides: int = 6):
    import random

    if sides < 1:
        await ctx.send("Please enter a number greater than 0!")
        return
    result = random.randint(1, sides)
    await ctx.send(f"🎲 You rolled a {result} (1-{sides})")


@bot.command()
async def flip(ctx):
    import random

    result = random.choice(["Heads", "Tails"])
    await ctx.send(f"🪙 {result}!")


@bot.command()
async def joke(ctx):
    import random

    jokes = [
        "Why don't scientists trust atoms? Because they make up everything!",
        "Why did the scarecrow win an award? He was outstanding in his field!",
        "Why don't eggs tell jokes? They'd crack each other up!",
        "What do you call a fake noodle? An impasta!",
        "Why did the math book look so sad? Because it had too many problems!",
    ]
    await ctx.send(random.choice(jokes))


@bot.command()
async def userinfo(ctx):
    user = ctx.author
    embed = discord.Embed(title=f"{user.name}'s Info", color=0x00FF00)
    embed.add_field(name="Username", value=user.name, inline=True)
    embed.add_field(name="ID", value=user.id, inline=True)
    embed.add_field(
        name="Joined Discord", value=user.created_at.strftime("%B %d, %Y"), inline=True
    )
    await ctx.send(embed=embed)


@bot.command()
async def serverinfo(ctx):
    guild = ctx.guild
    embed = discord.Embed(title=f"{guild.name} Server Info", color=0x0099FF)
    embed.add_field(name="Server Name", value=guild.name, inline=True)
    embed.add_field(name="Member Count", value=guild.member_count, inline=True)
    embed.add_field(
        name="Created", value=guild.created_at.strftime("%B %d, %Y"), inline=True
    )
    await ctx.send(embed=embed)


@bot.command()
async def calculate(ctx, *, expression):
    try:
        # Simple calculator - only allow basic operations for security
        allowed_chars = "0123456789+-*/(). "
        if all(c in allowed_chars for c in expression):
            result = eval(expression)
            await ctx.send(f"📊 {expression} = {result}")
        else:
            await ctx.send(
                "❌ Invalid characters in expression. Only numbers and +, -, *, /, (, ) are allowed."
            )
    except:
        await ctx.send("❌ Invalid expression. Please check your math!")


bot.run(os.getenv("TOKEN"))
