
from http.server import HTTPServer, SimpleHTTPRequestHandler
import os

class PolicyHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/privacy' or self.path == '/privacy/':
            self.path = '/privacy_policy.html'
        elif self.path == '/terms' or self.path == '/terms/':
            self.path = '/terms_of_service.html'
        return super().do_GET()

if __name__ == "__main__":
    port = 8080
    server = HTTPServer(('0.0.0.0', port), PolicyHandler)
    print(f"Policy server running on http://0.0.0.0:{port}")
    print(f"Privacy Policy: http://0.0.0.0:{port}/privacy")
    print(f"Terms of Service: http://0.0.0.0:{port}/terms")
    server.serve_forever()
