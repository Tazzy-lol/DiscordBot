from http.server import HTTPServer, BaseHTTPRequestHandler
import json

class LinkedRolesHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/linked-roles':
            content_length = int(self.headers['Content-Length'])
            raw_body = self.rfile.read(content_length)
            
            try:
                body = json.loads(raw_body.decode('utf-8'))
                
                # Basic linked roles verification
                response = {
                    "platform_name": "TazBot",
                    "platform_username": body.get("platform_username", "Unknown"),
                    "metadata": {
                        "verified": True,
                        "account_age": "30+ days"
                    }
                }
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response).encode())
                
            except Exception as e:
                self.send_response(400)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(b'<h1>TazBot Linked Roles</h1><p>This endpoint handles Discord linked roles verification.</p>')

if __name__ == "__main__":
    port = 3000
    server = HTTPServer(('0.0.0.0', port), LinkedRolesHandler)
    print(f"Linked Roles server running on http://0.0.0.0:{port}")
    print(f"Linked Roles Endpoint: http://0.0.0.0:{port}/linked-roles")
    server.serve_forever()
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os

class LinkedRolesHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/linked-roles':
            content_length = int(self.headers['Content-Length'])
            raw_body = self.rfile.read(content_length)
            
            try:
                body = json.loads(raw_body.decode('utf-8'))
                
                # Basic linked roles verification
                # You can customize this based on your bot's requirements
                response = {
                    "platform_name": "TazBot",
                    "platform_username": body.get("platform_username", "Unknown"),
                    "metadata": {
                        "verified": True,
                        "account_age": "30+ days"
                    }
                }
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response).encode())
                
            except Exception as e:
                self.send_response(400)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(b'<h1>TazBot Linked Roles</h1><p>This endpoint handles Discord linked roles verification.</p>')
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == "__main__":
    port = 3000
    server = HTTPServer(('0.0.0.0', port), LinkedRolesHandler)
    print(f"Linked Roles server running on http://0.0.0.0:{port}")
    print(f"Linked Roles Endpoint: http://0.0.0.0:{port}/linked-roles")
    server.serve_forever()
