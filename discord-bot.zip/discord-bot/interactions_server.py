
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import hashlib
import hmac
import os
from urllib.parse import parse_qs
from nacl.signing import VerifyKey
from nacl.exceptions import BadSignatureError

class InteractionsHandler(BaseHTTPRequestHandler):
    def verify_signature(self, raw_body, signature, timestamp):
        # Get Discord public key from environment (you'll need to set this)
        public_key = os.getenv('DISCORD_PUBLIC_KEY')
        print(f"Public key set: {'Yes' if public_key else 'No'}")
        print(f"Signature received: {signature[:20]}..." if signature else "No signature")
        print(f"Timestamp received: {timestamp}")
        
        if not public_key:
            print("Warning: DISCORD_PUBLIC_KEY not set - allowing request")
            return True  # Skip verification if key not set
        
        try:
            verify_key = VerifyKey(bytes.fromhex(public_key))
            message = timestamp.encode() + raw_body
            verify_key.verify(message, bytes.fromhex(signature))
            print("✅ Signature verification successful")
            return True
        except (BadSignatureError, ValueError) as e:
            print(f"❌ Signature verification failed: {e}")
            return False

    def do_POST(self):
        print(f"📥 POST request received to: {self.path}")
        print(f"📋 Headers: {dict(self.headers)}")
        
        if self.path == '/interactions':
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                raw_body = self.rfile.read(content_length)
                
                # Get Discord headers for signature verification
                signature = self.headers.get('X-Signature-Ed25519', '')
                timestamp = self.headers.get('X-Signature-Timestamp', '')
                
                print(f"🔐 Discord verification attempt:")
                print(f"   Signature: {signature[:20]}..." if signature else "   No signature")
                print(f"   Timestamp: {timestamp}")
                
                # Verify Discord signature
                if signature and timestamp:
                    if not self.verify_signature(raw_body, signature, timestamp):
                        print("❌ Signature verification failed - sending 401")
                        self.send_response(401)
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.end_headers()
                        return
                
                # Log for debugging
                print(f"📨 Request body: {raw_body.decode('utf-8')}")
                
                body = json.loads(raw_body.decode('utf-8'))
                
                # Handle ping from Discord (verification)
                if body.get('type') == 1:  # PING
                    print("🏓 Discord PING received - sending PONG")
                    response = {'type': 1}  # PONG
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
                    self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Signature-Ed25519, X-Signature-Timestamp')
                    self.end_headers()
                    self.wfile.write(json.dumps(response).encode())
                    print("✅ PONG response sent successfully")
                    return
                
                # Handle other interactions here
                print("💬 Handling interaction command")
                response = {'type': 4, 'data': {'content': 'Hello from TazBot!'}}
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps(response).encode())
                
            except Exception as e:
                print(f"❌ Error processing request: {e}")
                import traceback
                traceback.print_exc()
                self.send_response(400)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(b'{"error": "Bad Request"}')
        else:
            print(f"❌ Unknown path: {self.path}")
            self.send_response(404)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
    
    def do_OPTIONS(self):
        # Handle preflight requests
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
    
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(b'<h1>TazBot Interactions Endpoint</h1><p>This endpoint handles Discord interactions.</p>')
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == "__main__":
    port = 5000
    server = HTTPServer(('0.0.0.0', port), InteractionsHandler)
    print(f"Interactions server running on http://0.0.0.0:{port}")
    print(f"Interactions Endpoint: http://0.0.0.0:{port}/interactions")
    server.serve_forever()
